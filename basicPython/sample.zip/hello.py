"""Print a greeting message."""


def greet(name="World"):
    print(f"Hello, {name}! Welcome to Real Python!")
